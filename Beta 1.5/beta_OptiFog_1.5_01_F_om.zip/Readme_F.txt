=========================
  OptiFog 1.4_05_E
=========================

How to install:

Windows/Linux Instructions: 
1) Locate your minecraft.jar file. On Windows, it's in %APPDATA%/.minecraft/bin
2) Create a backup of minecraft.jar
3) Open minecraft.jar in an archive editor (WinRar/7-Zip/etc)
4) Delete the META-INF folder.
5) Copy the .class files from the downloaded zip file into the jar file, replacing previous files.
6) Run Minecraft and test!

Mac Instructions:
1) Locate your minecraft.jar file. On Mac, it's in <home>/Library/Application Support/minecraft/bin
2) Create a backup of minecraft.jar
3) rename minecraft.jar to minecraft.zip and double-click it to extract the contents
4) rename the resulting folder to minecraft.jar and open it
5) copy the .class files from the downloaded zip into the minecraft.jar folder, replacing previous files
6) Run Minecraft and test!

