What the mod does:
1. Pushes the fog away from the player so that it is only visible as transition on the render limits => looks better
2. Uses a fast fog type on FAST and a better looking fog type on FANCY settings => FPS boost
3. Decreases the render distance a little to get the same visible depth as before. On FAST decreases it even more to compensate for bad fog on screen edges => FPS boost
4. Added experimental Occlussion Culling (hidden geometry removal) so only visible objects are rendered. Helps a lot on bigger render distances, on FAR and NORMAL doubles the FPS.
5. Added Optimine compatible versions (both "inio" and "303" versions of Optimine).
6. Added Texture mipmapping - far distances blend nicely, no more eyestrain.
7. Modular and configurable

To install only some functions, install only the corresponding class files.

Config.class and ConfigData class are always REQUIRED.

Name                Class name          Required    Functions    
=======================================================================================================================================
Config              Config.class        YES         <configuration>
ConfigData          ConfigData.class    YES         <configuration>
EntityRenderer      mw.class            optional    FogFancy, FogStart, OptimizeRenderDistance, AlphaFunc, AlphaFuncLevel 
RenderEngine        ho.class            optional    MipmapType, MipmapLevel
OpenGlCapsChecker   cd.class            optional    OcclusionEnabled
RenderGlobal        i.class             optional    OcclusionEnabled, <fix for sunset rendering, nice with EntityRenderer (mw.class)>

If you use mw.class then add also i.class if possible, sunsets will look much better.

Copy optifog.txt to the minecraft directory (where options.txt is located)

Edit optifog.txt and enable/disable the options you need.

Without correctly installed options.txt OptiFog disables ALL its functions and works exactly as a plain Minecraft.

Copy optifog_CLASSIC.txt to optifog.txt to enables the functions of OptiFog classic.
Copy optifog_OC.txt to optifog.txt to enables the functions of OptiFog experimental.
Copy optifog_OC_MM.txt to optifog.txt to enables the functions of OptiFog experimental + mipmaps.

Windows/Linux Instructions: (copied from Optimine)
1) Locate your minecraft.jar file. On Windows, it's in %APPDATA%/.minecraft/bin
2) Create a backup of minecraft.jar
3) Open minecraft.jar in an archive editor (WinRar/7-Zip/etc)
4) Delete the META-INF folder.
5) Copy the .class files from the downloaded zip file into the jar file, replacing previous files.
6) Run Minecraft and test!

Mac Instructions:
1) Locate your minecraft.jar file. On Mac, it's in <home>/Library/Application Support/minecraft/bin
2) Create a backup of minecraft.jar
3) rename minecraft.jar to minecraft.zip and double-click it to extract the contents
4) rename the resulting folder to minecraft.jar and open it
5) copy the .class files from the downloaded zip into the minecraft.jar folder, replacing previous files
6) Run Minecraft and test!